require("dotenv").config();

const express = require("express");
const cors = require("cors");
const fs = require("fs");
const path = require("path");
const session = require("express-session");
const bcrypt = require("bcryptjs");
const QRCode = require("qrcode");
const { Client, LocalAuth } = require("whatsapp-web.js");

const app = express();

app.use(cors({
  origin: true,
  credentials: true
}));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, "..", "public")));

const PORT = process.env.PORT || 3000;
const DB_PATH = path.join(__dirname, "..", "database", "saas.json");
const SESSIONS_PATH = path.join(__dirname, "..", "sessions");

app.set("trust proxy", 1);

app.use(
  session({
    secret: process.env.SESSION_SECRET || "atendeplus_saas_secret",
    resave: false,
    saveUninitialized: false,
    cookie: {
      secure: false,
      httpOnly: true,
      sameSite: "lax",
      maxAge: 1000 * 60 * 60 * 12,
    },
  })
);

function ensureDir(dirPath) {
  if (!fs.existsSync(dirPath)) {
    fs.mkdirSync(dirPath, { recursive: true });
  }
}

function gerarId(prefixo = "id") {
  return `${prefixo}_${Date.now()}_${Math.floor(Math.random() * 1000)}`;
}

function getInitialDB() {
  const senhaHashAdmin = bcrypt.hashSync("123456", 10);

  return {
    superAdmin: {
      email: "admin@atendeplus.com",
      senhaHash: senhaHashAdmin,
    },
    usuarios: [],
    empresas: [],
    sessoesWhatsapp: [],
  };
}

function ensureDB() {
  ensureDir(path.dirname(DB_PATH));
  ensureDir(SESSIONS_PATH);

  if (!fs.existsSync(DB_PATH)) {
    fs.writeFileSync(DB_PATH, JSON.stringify(getInitialDB(), null, 2), "utf-8");
    return;
  }

  try {
    const raw = fs.readFileSync(DB_PATH, "utf-8");
    const db = JSON.parse(raw);

    let changed = false;

    if (!db.superAdmin || typeof db.superAdmin !== "object") {
      db.superAdmin = getInitialDB().superAdmin;
      changed = true;
    }

    if (!db.superAdmin.email) {
      db.superAdmin.email = "admin@atendeplus.com";
      changed = true;
    }

    if (!db.superAdmin.senhaHash) {
      db.superAdmin.senhaHash = bcrypt.hashSync("123456", 10);
      changed = true;
    }

    if (!Array.isArray(db.usuarios)) {
      db.usuarios = [];
      changed = true;
    }

    if (!Array.isArray(db.empresas)) {
      db.empresas = [];
      changed = true;
    }

    if (!Array.isArray(db.sessoesWhatsapp)) {
      db.sessoesWhatsapp = [];
      changed = true;
    }

    if (changed) {
      fs.writeFileSync(DB_PATH, JSON.stringify(db, null, 2), "utf-8");
    }
  } catch (err) {
    console.error("Erro ao validar saas.json. Verifique se o JSON está válido.");
    throw err;
  }
}

function readDB() {
  ensureDB();
  return JSON.parse(fs.readFileSync(DB_PATH, "utf-8"));
}

function writeDB(data) {
  fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2), "utf-8");
}

const waClients = new Map();

function getEmpresaSessionPath(empresaId) {
  return path.join(SESSIONS_PATH, empresaId);
}

function getChromeExecutablePath() {
  const possible = [
    process.env.CHROME_PATH,
    "/usr/bin/google-chrome-stable",
    "/usr/bin/google-chrome",
    "/usr/bin/chromium-browser",
    "/usr/bin/chromium",
  ].filter(Boolean);

  return possible.find((p) => fs.existsSync(p)) || undefined;
}

async function updateWhatsappSession(empresaId, patch) {
  const db = readDB();

  if (!Array.isArray(db.sessoesWhatsapp)) {
    db.sessoesWhatsapp = [];
  }

  const idx = db.sessoesWhatsapp.findIndex((s) => s.empresaId === empresaId);

  const base = {
    empresaId,
    status: "desconectado",
    qr: null,
    numero: null,
    lastError: null,
    ultimaAtualizacao: new Date().toISOString(),
  };

  if (idx === -1) {
    db.sessoesWhatsapp.push({ ...base, ...patch });
  } else {
    db.sessoesWhatsapp[idx] = {
      ...db.sessoesWhatsapp[idx],
      ...patch,
      ultimaAtualizacao: new Date().toISOString(),
    };
  }

  writeDB(db);
}

function getWhatsappSession(empresaId) {
  const db = readDB();

  if (!Array.isArray(db.sessoesWhatsapp)) {
    db.sessoesWhatsapp = [];
  }

  return (
    db.sessoesWhatsapp.find((s) => s.empresaId === empresaId) || {
      empresaId,
      status: "desconectado",
      qr: null,
      numero: null,
      lastError: null,
      ultimaAtualizacao: null,
    }
  );
}

async function initWhatsAppClient(empresaId) {
  if (waClients.has(empresaId)) {
    return waClients.get(empresaId);
  }

  ensureDir(getEmpresaSessionPath(empresaId));

  const chromePath = getChromeExecutablePath();

  const client = new Client({
    authStrategy: new LocalAuth({
      clientId: empresaId,
      dataPath: SESSIONS_PATH,
    }),
    puppeteer: {
      headless: true,
      executablePath: chromePath,
      args: ["--no-sandbox", "--disable-setuid-sandbox"],
    },
  });

  client.on("qr", async (qr) => {
    try {
      const qrDataUrl = await QRCode.toDataURL(qr);
      await updateWhatsappSession(empresaId, {
        status: "aguardando_qr",
        qr: qrDataUrl,
        lastError: null,
      });
      console.log(`[WA ${empresaId}] QR atualizado`);
    } catch (err) {
      console.error(`[WA ${empresaId}] erro ao gerar QR`, err);
      await updateWhatsappSession(empresaId, {
        status: "erro_qr",
        lastError: String(err.message || err),
      });
    }
  });

  client.on("authenticated", async () => {
    await updateWhatsappSession(empresaId, {
      status: "autenticado",
      lastError: null,
    });
    console.log(`[WA ${empresaId}] autenticado`);
  });

  client.on("ready", async () => {
    let numero = null;

    try {
      numero = client.info?.wid?.user || null;
    } catch {}

    await updateWhatsappSession(empresaId, {
      status: "conectado",
      qr: null,
      numero,
      lastError: null,
    });

    console.log(`[WA ${empresaId}] conectado`);
  });

  client.on("auth_failure", async (msg) => {
    await updateWhatsappSession(empresaId, {
      status: "falha_autenticacao",
      qr: null,
      lastError: msg || "Falha de autenticação",
    });
    console.error(`[WA ${empresaId}] auth_failure`, msg);
  });

  client.on("disconnected", async (reason) => {
    await updateWhatsappSession(empresaId, {
      status: "desconectado",
      qr: null,
      lastError: String(reason || "Desconectado"),
      numero: null,
    });

    waClients.delete(empresaId);
    console.warn(`[WA ${empresaId}] desconectado`, reason);
  });

  await updateWhatsappSession(empresaId, {
    status: "inicializando",
    qr: null,
    lastError: null,
  });

  client.initialize().catch(async (err) => {
    console.error(`[WA ${empresaId}] erro ao inicializar`, err);
    await updateWhatsappSession(empresaId, {
      status: "erro",
      qr: null,
      lastError: String(err.message || err),
    });
    waClients.delete(empresaId);
  });

  waClients.set(empresaId, client);
  return client;
}

async function destroyWhatsAppClient(empresaId) {
  const client = waClients.get(empresaId);

  if (client) {
    try {
      await client.destroy();
    } catch (err) {
      console.error(`[WA ${empresaId}] erro ao destruir client`, err);
    }
    waClients.delete(empresaId);
  }

  await updateWhatsappSession(empresaId, {
    status: "desconectado",
    qr: null,
    numero: null,
    lastError: null,
  });
}

function authMiddleware(req, res, next) {
  if (!req.session || !req.session.user) {
    return res.status(401).json({
      ok: false,
      message: "Sessão não encontrada.",
    });
  }
  next();
}

function superAdminMiddleware(req, res, next) {
  if (req.session?.user?.tipo === "super_admin") return next();

  return res.status(403).json({
    ok: false,
    message: "Acesso negado.",
  });
}

function clienteMiddleware(req, res, next) {
  if (!req.session?.user) {
    return res.status(401).json({
      ok: false,
      message: "Sessão não encontrada.",
    });
  }

  if (["admin_empresa", "atendente"].includes(req.session.user.tipo)) {
    return next();
  }

  return res.status(403).json({
    ok: false,
    message: "Acesso negado.",
  });
}

/* =========================
   ROTAS DE PÁGINAS
========================= */

app.get("/", (req, res) => {
  res.redirect("/login.html");
});

app.get("/login.html", (req, res) => {
  res.sendFile(path.join(__dirname, "..", "public", "login.html"));
});

app.get("/cadastro.html", (req, res) => {
  res.sendFile(path.join(__dirname, "..", "public", "cadastro.html"));
});

app.get("/cliente.html", (req, res) => {
  res.sendFile(path.join(__dirname, "..", "public", "cliente.html"));
});

app.get("/admin.html", (req, res) => {
  res.sendFile(path.join(__dirname, "..", "public", "admin.html"));
});

/* =========================
   ROTAS DE STATUS
========================= */

app.get("/api/status", (req, res) => {
  res.json({
    ok: true,
    app: "Atende+ SaaS",
  });
});

app.get("/api/me", authMiddleware, (req, res) => {
  res.json({
    ok: true,
    user: req.session.user,
  });
});

/* =========================
   AUTENTICAÇÃO
========================= */

app.post("/api/login", async (req, res) => {
  try {
    const { email, senha } = req.body;

    if (!email || !senha) {
      return res.status(400).json({
        ok: false,
        message: "Informe e-mail e senha.",
      });
    }

    const db = readDB();

    if (
      db.superAdmin &&
      email.toLowerCase() === db.superAdmin.email.toLowerCase()
    ) {
      const senhaOkSuperAdmin = await bcrypt.compare(
        senha,
        db.superAdmin.senhaHash
      );

      if (senhaOkSuperAdmin) {
        req.session.user = {
          id: "super_admin",
          nome: "Super Admin",
          email: db.superAdmin.email,
          tipo: "super_admin",
        };

        return res.json({
          ok: true,
          message: "Login realizado com sucesso.",
          redirect: "/admin.html",
          user: req.session.user,
        });
      }
    }

    const usuarios = Array.isArray(db.usuarios) ? db.usuarios : [];
    const empresas = Array.isArray(db.empresas) ? db.empresas : [];

    const usuario = usuarios.find(
      (u) => (u.email || "").toLowerCase() === email.toLowerCase()
    );

    if (!usuario) {
      return res.status(401).json({
        ok: false,
        message: "Usuário ou senha inválidos.",
      });
    }

    const senhaOk = await bcrypt.compare(senha, usuario.senhaHash);

    if (!senhaOk) {
      return res.status(401).json({
        ok: false,
        message: "Usuário ou senha inválidos.",
      });
    }

    const empresa = empresas.find((e) => e.id === usuario.empresaId);

    req.session.user = {
      id: usuario.id,
      nome: usuario.nome,
      email: usuario.email,
      tipo: usuario.tipo,
      empresaId: usuario.empresaId || null,
      empresa: empresa ? empresa.nome : null,
    };

    return res.json({
      ok: true,
      message: "Login realizado com sucesso.",
      redirect:
        usuario.tipo === "admin_empresa" || usuario.tipo === "atendente"
          ? "/cliente.html"
          : "/login.html",
      user: req.session.user,
    });
  } catch (err) {
    console.error("Erro no login:", err);
    return res.status(500).json({
      ok: false,
      message: "Erro ao realizar login.",
    });
  }
});

app.post("/api/logout", (req, res) => {
  req.session.destroy(() => {
    res.json({
      ok: true,
      message: "Logout realizado com sucesso.",
    });
  });
});

/* =========================
   SUPER ADMIN - EMPRESAS
========================= */

app.get(
  "/api/admin/empresas",
  authMiddleware,
  superAdminMiddleware,
  (req, res) => {
    try {
      const db = readDB();

      if (!Array.isArray(db.empresas)) db.empresas = [];
      if (!Array.isArray(db.usuarios)) db.usuarios = [];
      if (!Array.isArray(db.sessoesWhatsapp)) db.sessoesWhatsapp = [];

      const empresas = db.empresas.map((empresa) => {
        const totalUsuarios = db.usuarios.filter(
          (u) => u.empresaId === empresa.id
        ).length;

        const sessao = db.sessoesWhatsapp.find(
          (s) => s.empresaId === empresa.id
        );

        return {
          ...empresa,
          totalUsuarios,
          whatsappStatus: sessao ? sessao.status : "desconectado",
        };
      });

      return res.json({
        ok: true,
        empresas,
      });
    } catch (err) {
      console.error("Erro ao listar empresas:", err);
      return res.status(500).json({
        ok: false,
        message: "Erro ao listar empresas.",
      });
    }
  }
);

app.post(
  "/api/admin/empresas",
  authMiddleware,
  superAdminMiddleware,
  async (req, res) => {
    try {
      const {
        nomeEmpresa,
        emailEmpresa,
        nomeAdmin,
        emailAdmin,
        senha,
        plano,
      } = req.body;

      if (!nomeEmpresa || !emailEmpresa || !nomeAdmin || !emailAdmin || !senha || !plano) {
        return res.status(400).json({
          ok: false,
          message: "Preencha todos os campos.",
        });
      }

      const db = readDB();

      if (!Array.isArray(db.empresas)) db.empresas = [];
      if (!Array.isArray(db.usuarios)) db.usuarios = [];
      if (!Array.isArray(db.sessoesWhatsapp)) db.sessoesWhatsapp = [];

      const empresaExistente = db.empresas.find(
        (e) => (e.email || "").toLowerCase() === emailEmpresa.toLowerCase()
      );

      if (empresaExistente) {
        return res.status(400).json({
          ok: false,
          message: "Já existe uma empresa com esse e-mail.",
        });
      }

      const usuarioExistente = db.usuarios.find(
        (u) => (u.email || "").toLowerCase() === emailAdmin.toLowerCase()
      );

      if (usuarioExistente) {
        return res.status(400).json({
          ok: false,
          message: "Já existe um usuário com esse e-mail.",
        });
      }

      const empresaId = `emp_${Date.now()}`;
      const usuarioId = `usr_${Date.now()}`;
      const senhaHash = await bcrypt.hash(senha, 10);

      const novaEmpresa = {
        id: empresaId,
        nome: nomeEmpresa,
        email: emailEmpresa,
        plano,
        status: "ativo",
        limiteUsuarios: plano === "start" ? 2 : plano === "pro" ? 5 : 20,
        limiteConexoes: plano === "start" ? 1 : plano === "pro" ? 2 : 5,
        criadoEm: new Date().toISOString(),
      };

      const novoUsuario = {
        id: usuarioId,
        empresaId,
        nome: nomeAdmin,
        email: emailAdmin,
        senhaHash,
        tipo: "admin_empresa",
        status: "ativo",
        criadoEm: new Date().toISOString(),
      };

      const novaSessao = {
        empresaId,
        status: "desconectado",
        qr: null,
        numero: null,
        lastError: null,
        ultimaAtualizacao: new Date().toISOString(),
      };

      db.empresas.push(novaEmpresa);
      db.usuarios.push(novoUsuario);
      db.sessoesWhatsapp.push(novaSessao);

      writeDB(db);

      return res.json({
        ok: true,
        message: "Empresa criada com sucesso.",
        empresa: novaEmpresa,
        usuario: {
          id: novoUsuario.id,
          nome: novoUsuario.nome,
          email: novoUsuario.email,
        },
      });
    } catch (err) {
      console.error("Erro ao criar empresa:", err);
      return res.status(500).json({
        ok: false,
        message: "Erro interno ao criar empresa.",
        error: err.message,
      });
    }
  }
);

app.post(
  "/api/admin/entrar-empresa",
  authMiddleware,
  superAdminMiddleware,
  (req, res) => {
    try {
      const { empresaId } = req.body;

      if (!empresaId) {
        return res.status(400).json({
          ok: false,
          message: "empresaId é obrigatório.",
        });
      }

      const db = readDB();

      if (!Array.isArray(db.empresas)) db.empresas = [];
      if (!Array.isArray(db.usuarios)) db.usuarios = [];

      const empresa = db.empresas.find((e) => e.id === empresaId);

      if (!empresa) {
        return res.status(404).json({
          ok: false,
          message: "Empresa não encontrada.",
        });
      }

      const adminEmpresa = db.usuarios.find(
        (u) => u.empresaId === empresaId && u.tipo === "admin_empresa"
      );

      if (!adminEmpresa) {
        return res.status(404).json({
          ok: false,
          message: "Admin da empresa não encontrado.",
        });
      }

      req.session.user = {
        id: adminEmpresa.id,
        nome: adminEmpresa.nome,
        email: adminEmpresa.email,
        tipo: adminEmpresa.tipo,
        empresaId: empresa.id,
        empresa: empresa.nome,
        entrouComoSuperAdmin: true,
      };

      return res.json({
        ok: true,
        message: "Entrou na empresa com sucesso.",
        redirect: "/cliente.html",
      });
    } catch (err) {
      console.error("Erro ao entrar na empresa:", err);
      return res.status(500).json({
        ok: false,
        message: "Erro ao entrar na empresa.",
      });
    }
  }
);

/* =========================
   CLIENTE / WHATSAPP
========================= */

app.post(
  "/api/cliente/whatsapp/conectar",
  authMiddleware,
  clienteMiddleware,
  async (req, res) => {
    try {
      const empresaId = req.session.user.empresaId;
      await initWhatsAppClient(empresaId);

      return res.json({
        ok: true,
        message: "Inicialização do WhatsApp iniciada.",
      });
    } catch (err) {
      console.error("Erro ao iniciar WhatsApp:", err);
      return res.status(500).json({
        ok: false,
        message: "Erro ao iniciar WhatsApp.",
      });
    }
  }
);

app.get(
  "/api/cliente/whatsapp/status",
  authMiddleware,
  clienteMiddleware,
  (req, res) => {
    try {
      const empresaId = req.session.user.empresaId;
      const sessao = getWhatsappSession(empresaId);

      return res.json({
        ok: true,
        status: sessao.status,
        qr: sessao.qr || null,
        numero: sessao.numero || null,
        lastError: sessao.lastError || null,
        ultimaAtualizacao: sessao.ultimaAtualizacao || null,
      });
    } catch (err) {
      console.error("Erro ao consultar status do WhatsApp:", err);
      return res.status(500).json({
        ok: false,
        message: "Erro ao consultar status do WhatsApp.",
      });
    }
  }
);

app.post(
  "/api/cliente/whatsapp/desconectar",
  authMiddleware,
  clienteMiddleware,
  async (req, res) => {
    try {
      const empresaId = req.session.user.empresaId;
      await destroyWhatsAppClient(empresaId);

      return res.json({
        ok: true,
        message: "WhatsApp desconectado com sucesso.",
      });
    } catch (err) {
      console.error("Erro ao desconectar WhatsApp:", err);
      return res.status(500).json({
        ok: false,
        message: "Erro ao desconectar WhatsApp.",
      });
    }
  }
);

/* =========================
   START
========================= */

ensureDB();

app.listen(PORT, "0.0.0.0", () => {
  console.log(`🚀 Atende-SaaS rodando em http://localhost:${PORT}`);
});
