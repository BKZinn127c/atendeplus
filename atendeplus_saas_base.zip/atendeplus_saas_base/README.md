# Atende+ SaaS Base

## Instalação
```bash
npm install
pm2 start backend/server.js --name server
```

## Login padrão
- email: admin@atendeplus.com
- senha: 123456

## Se quiser recriar o banco
```bash
rm database/saas.json
pm2 restart all
```

## Estrutura
- backend/server.js
- public/login.html
- public/admin.html
- public/cliente.html
- public/cadastro.html
- database/saas.json
- sessions/

## Observação
Para o QR do WhatsApp funcionar na VPS, tenha Chrome/Chromium instalado e ajuste CHROME_PATH se necessário.
